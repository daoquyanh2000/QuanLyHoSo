//Ghep noi ban phim 4x3 va LCD 16x2 voi vi dieu khien 89C51
unsigned short kp, cnt, oldstate = 0;
char txt[6];
char keypadPort at P0; //K�t n��i ba`n phi�m vo�i c�?ng P0
sbit LCD_RS at P1_0_bit; //K�t n��i LCD vo�i c�?ng P1
sbit LCD_EN at P1_1_bit;
sbit LCD_D4 at P1_2_bit;
sbit LCD_D5 at P1_3_bit;
sbit LCD_D6 at P1_4_bit;
sbit LCD_D7 at P1_5_bit;
void main() {
 cnt = 0; // Xo�a b�? d�m
 Keypad_Init(); // Kho?i ta?o ba`n phi�m
 Lcd_Init(); // Kho?i ta?o LCD
 Lcd_Cmd(_LCD_CLEAR); // Xo�a ma`n hi`nh hi�?n thi?
 Lcd_Cmd(_LCD_CURSOR_OFF); // Kh�ng hi�?n thi? con tro?
 Lcd_Out(1, 1, "Key :"); // Ghi ra ha`ng 1 c�?t 1
 Lcd_Out(2, 1, "Times:"); // Ghi ra ha`ng 2 c�?t 1
 do {
 kp = 0; // Xo�a bi�n ma~ phi�m
 // cho` cho 1 phi�m duo?c �n va` nha?
 do
 kp = Keypad_Key_Click(); // Luu ma~ phi�m va`o bi�n kp
 while (!kp);
 // Chuy�?n phi�m tha`nh ma~ ASCII
 switch (kp) {
 case 1: kp = 49; break; // phi�m 1
 case 2: kp = 50; break; // phi�m 2
 case 3: kp = 51; break; // phi�m 3
 case 5: kp = 52; break; // phi�m 4
 case 6: kp = 53; break; // phi�m 5
 case 7: kp = 54; break; // phi�m 6
 case 9: kp = 55; break; // phi�m 7
 case 10: kp = 56; break; // phi�m 8
 case 11: kp = 57; break; // phi�m 9
 case 13: kp = 42; break; // phi�m *
 case 14: kp = 48; break; // phi�m 0
 case 15: kp = 35; break; // phi�m #

 }
 if (kp != oldstate){
//N�u nh�n 1 phi�m kha�c vo�i phi�m truo�c do�
 cnt = 1;
 oldstate = kp;
 }
 else {//N�u nh�n 1 phi�m gi��ng phi�m truo�c do�
 cnt++;
 }
 Lcd_Chr(1, 10, kp); // In ky� tu? ASCII ra LCD
 if (cnt == 255) { // N�u tra`n bi�n d�m
 cnt = 0;
 Lcd_Out(2, 10, " ");
 }
WordToStr(cnt, txt);
//Chuy�?n gia� tri? d�m duo?c tha`ng chu�~i ky� tu?
 Lcd_Out(2, 10, txt); // Hi�?n thi? gia� tri? d�m tr�n LCD
 } while (1);
}
